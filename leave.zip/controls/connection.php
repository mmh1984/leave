<?php
$server='locahost';
$user='root';
$pass='';
$db='kemuda';
//$conn=mysqli_connect('localhost','root','','kemuda_leave') or die (mysqli_error());	
$conn=mysqli_connect('108.167.189.71','maynardm_maynard','KEMUDA2020?','maynardm_kileavedb') or die(mysqli_error());


?>